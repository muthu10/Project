import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Basket from "./Basket";

class Catalog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      products: [],
      myCartItems: []
    };

    this.saveDataIntoRedis = this.saveDataIntoRedis.bind(this);
  }
  saveDataIntoRedis() {
    let myCartItems = this.state.myCartItems;
    var cartItems = {
      CustomerId: 1,
      myCartItems
    };
    console.log(cartItems);
  }
  getItem(elemet) {
    var cartItems = {
      CustomerId: elemet.id,
      Products: {
        Id: elemet.id,
        ProductId: "Prod" + elemet.id,
        ProductName: elemet.name,
        UnitPrice: elemet.cost,
        Quantity: 10,
        ImageUrl: elemet.imageUrl
      }
    };

    axios
      .post("http://localhost:7002/api/basket", cartItems)
      .then(response => {
        // handle success
        // this.setState({ products: response.data });
        console.log("After added cart items: ", response.data);
      })
      .catch(error => {
        // handle error
        console.log("Error: ", error);
      });
  }

  componentDidMount() {
    axios
      .get("http://localhost:7001/api/catalog")
      .then(response => {
        // handle success
        this.setState({ products: response.data });
        console.log("products: ", this.state.products);
      })
      .catch(error => {
        // handle error
        console.log("Error: ", error);
      });
  }
  render() {
    const productJSx = this.state.products.map(element => (
      <div className="col-lg-4" key={element.id}>
        <a href={element.imageUrl}>
          <img src={element.imageUrl} alt="Lights" style={{ width: "30%" }} />
          <div className="caption">
            <p>{element.name}</p>
            <p>
              $Price:
              {element.cost}
            </p>
          </div>
        </a>
        <button
          onClick={() => {
            this.getItem(element);
          }}
        >
          Add to cart
        </button>
      </div>
    ));
    return (
      <div className="container">
        <div className="row">{productJSx}</div>
        <div className="roe">
          <button onClick={this.saveDataIntoRedis}>Check Out</button>
        </div>
      </div>
    );
  }
}

export default Catalog;

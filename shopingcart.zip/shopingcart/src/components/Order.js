import React from "react";
import axios from "axios";

class Order extends React.Component {
  constructor(props) {
    super(props);
    this.placeOrder = this.placeOrder.bind(this);
    var products = JSON.parse(localStorage.getItem("products"));
    console.log(products);
  }

  placeOrder() {
    var products = JSON.parse(localStorage.getItem("products"));
    console.log(products);
    const order = {
      FirstName: this.firstName.value,
      LastName: this.lastName.value,
      Email: this.email.value,
      PhoneNumber: this.phone.value,
      Address: this.address.value,
      ProductName: products.productName,
      Quantity: products.unitPrice,
      Price: products.quantity
    };
    axios
      .post("http://localhost:7003/api/orders", order)
      .then(response => {
        console.log("After added cart items: ", response.data);
      })
      .catch(error => {
        // handle error
        console.log("Error: ", error);
      });
    console.log(this.order);
  }
  render() {
    return (
      <div>
        <h2>User details</h2>
        <table className="table table-bordered">
          <tbody>
            <tr>
              <th>
                <label>First Name:</label>
              </th>
              <th>
                <input type="text" ref={node => (this.firstName = node)} />
              </th>
            </tr>
            <tr>
              <th>
                <label>last Name:</label>
              </th>
              <th>
                <input type="text" ref={node => (this.lastName = node)} />
              </th>
            </tr>
            <tr>
              <th>
                <label>Email:</label>
              </th>
              <th>
                <input type="text" ref={node => (this.email = node)} />
              </th>
            </tr>
            <tr>
              <th>
                <label>Phone Number:</label>
              </th>
              <th>
                <input type="text" ref={node => (this.phone = node)} />
              </th>
            </tr>
            <tr>
              <th>
                <label>Address:</label>
              </th>
              <th>
                <input type="text" ref={node => (this.address = node)} />
              </th>
            </tr>
            <tr>
              <th colSpan="2">
                <input
                  type="button"
                  value="PlaceOrder"
                  className="center"
                  onClick={this.placeOrder}
                />
              </th>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

export default Order;

import React from "react";
import { UserManager } from "oidc-client";

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.loginClick = this.loginClick.bind(this);
  }
  loginClick() {
    var config = {
      authority: "http://localhost:7000",
      client_id: "spa",
      redirect_uri: "http://localhost:3000/catalog",
      response_type: "id_token token",
      scope: "openid profile BlogAPI",
      post_logout_redirect_uri: "http://localhost:3000/catalog"
    };
    var mgr = new UserManager(config);
    mgr.signinRedirect();
  }
  render() {
    return <button onClick={this.loginClick()}>Login</button>;
  }
}

export default Login;

import React from "react";
import { Route, Switch } from "react-router-dom";

import Catalog from "./Catalog";
import Basket from "./Basket";
import Login from "./Login";
import Signup from "./Signup";
import AddCatalog from "./AddCatalog";
import Order from "./Order";

class Content extends React.Component {
  render() {
    return (
      <div>
        <Switch>
          <Route exact path="/catalog" component={Catalog} />
          <Route path="/add-catalog" component={AddCatalog} />
          <Route path="/catalog" component={Catalog} />
          <Route path="/basket" component={Basket} />
          <Route path="/order" component={Order} />
          <Route path="/login" component={Login} />
          <Route path="/signup" component={Signup} />
        </Switch>
      </div>
    );
  }
}

export default Content;

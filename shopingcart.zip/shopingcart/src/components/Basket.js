import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";

class Basket extends React.Component {
  constructor(props) {
    super(props);
    this.state = { products: [] };
    this.selectProducts = this.selectProducts.bind(this);
  }

  selectProducts(el) {
    localStorage.setItem("products", JSON.stringify(el.products));
    console.log(el.products);
  }

  componentDidMount() {
    console.log("After moving to Basket :", this.props.test);
    axios
      .get("http://localhost:7002/api/basket")
      .then(response => {
        // handle success
        this.setState({ products: response.data });
        console.log("products: ", this.state.products);
      })
      .catch(error => {
        // handle error
        console.log("Error: ", error);
      });
  }

  render() {
    console.log("Welcome: ", JSON.stringify(this.state.products));
    const BasketJSx = this.state.products.map(element => (
      <div className="row" key={element.products.id}>
        <div className="col-sm-2">
          <a href={element.imageUrl}>
            <img
              src={element.products.imageUrl}
              alt="Lights"
              style={{ width: "30%" }}
            />
            <div className="caption">
              <p>{element.products.productName}</p>
            </div>
          </a>
        </div>
        <div className="col-sm-2">
          <input
            maxLength="3"
            type="text"
            name="qty"
            defaultValue={element.products.quantity}
          />
        </div>
        <div className="col-sm-2">
          <input
            maxLength="3"
            type="text"
            name="price"
            defaultValue={element.products.quantity}
          />
        </div>
        <div className="col-sm-2">
          <input
            type="checkbox"
            name={element}
            // onChange={this.selectProducts}
            onChange={() => {
              this.selectProducts(element);
            }}
          />
        </div>
      </div>
    ));

    return (
      <div>
        <div className="row">
          <div className="col-sm-2">ProductName</div>
          <div className="col-sm-2">Price</div>
          <div className="col-sm-2">Quantity</div>
          <div className="col-sm-2">Select Product</div>
        </div>
        {BasketJSx}
        <div className="row">
          <div className="col-sm-2">
            <Link to={`/Order`}>
              <button type="submit" name="Checkout">
                CheckOut
              </button>
            </Link>
          </div>
          <div className="col-sm-2">
            <Link to={`/Catalog`}>
              <button type="submit" name="continue">
                Continue to Shopping
              </button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
}

export default Basket;

import React from "react";

import { Link } from "react-router-dom";

class Nav extends React.Component {
  render() {
    return (
      <div>
        <nav className="navbar navbar-inverse">
          <div className="container-fluid">
            <div className="navbar-header">
              <Link className="navbar-brand" to="./Catalog">
                Shooping cart
              </Link>
            </div>
            <ul className="nav navbar-nav">
              <li className="active">
                <Link to="./catalog">Catalog</Link>
              </li>
              <li className="active">
                <Link to="./add-catalog">Add Catalog</Link>
              </li>
              <li className="active">
                <Link to="./basket">Basket</Link>
              </li>
              <li>
                <Link to="./order">Order</Link>
              </li>
            </ul>
            <ul className="nav navbar-nav navbar-right">
              <li>
                <Link to="./sign-up">
                  <span className="glyphicon glyphicon-user" /> Sign Up
                </Link>
              </li>
              <li>
                <Link to="./login">
                  <span className="glyphicon glyphicon-log-in" /> Login
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    );
  }
}

export default Nav;

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatalogAPI.Models
{
    public class EntityBase
    {
        public virtual int Id { set; get; }
    }
}

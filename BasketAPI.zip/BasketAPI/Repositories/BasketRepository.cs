﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;
using Basket.API.Models;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using StackExchange.Redis;

namespace Basket.API.Repositories
{
    public class BasketRepository : IBasketRepository
    {

        private readonly ILogger<BasketRepository> _logger;

        private readonly ConnectionMultiplexer _redis;
        private readonly IDatabase _database;

        public BasketRepository(ILoggerFactory loggerFactory, ConnectionMultiplexer redis)
        {
            _logger = loggerFactory.CreateLogger<BasketRepository>();
            _redis = redis;
            _database = redis.GetDatabase();
        }

        public async Task<Customer> AddBasketAsync(Customer customer)
        {

            var created = await _database.StringSetAsync(customer.CustomerId, JsonConvert.SerializeObject(customer));
            if (!created)
            {
                _logger.LogInformation("Problem occur persisting the item.");
                return null;
            }

            _logger.LogInformation("Basket item persisted succesfully.");

            return await GetBasketAsync(customer.CustomerId);
        }

        public bool ClearBasket(Customer customer)
        {
            var server = GetServer();
            server.FlushDatabase();

            return true;

        }

        public async Task<List<Customer>> DeleteBasketAsync(string id)
        {
           

            var result = await _database.KeyDeleteAsync(id);

            var server = GetServer();
            var data = server.Keys();
            IEnumerable<string> keys = data?.Select(k => k.ToString());
            var lst = new List<Customer>();

            foreach (var item in keys)
            {
                var getItem = await _database.StringGetAsync(item);

                if (!getItem.IsNullOrEmpty)
                {
                    lst.Add(JsonConvert.DeserializeObject<Customer>(getItem));
                }
            }
            return lst;
        }

        public async Task<Customer> GetBasketAsync(string customerId)
        {
            var data = await _database.StringGetAsync(customerId);
            if (data.IsNullOrEmpty)
                return null;
            else
                return JsonConvert.DeserializeObject<Customer>(data);
        }
               
        public async Task<List<Customer>> GetAllItems()
        {
            var server = GetServer();
            var data = server.Keys();
            IEnumerable<string> keys = data?.Select(k => k.ToString());
            var lst = new List<Customer>();

            foreach (var item in keys)
            {
                var getItem = await _database.StringGetAsync(item);

                if (!getItem.IsNullOrEmpty)
                {
                    lst.Add(JsonConvert.DeserializeObject<Customer>(getItem));
                }


            }

            return lst;
        }

        private IServer GetServer()
        {
            var endpoint = _redis.GetEndPoints();
            return _redis.GetServer(endpoint.First());
        }

    }
}
